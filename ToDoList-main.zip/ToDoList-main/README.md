# ToDoList App
ToDoList app help you to manage your daily task.

# About Project

- This project built on Android Studio Koala | 2024.1.1 Beta 1

# How to Use?

- Click on FAB add button to add task.
- Also you can import demo tasks database from three dot menu.
- Long press on any task to perform more action.